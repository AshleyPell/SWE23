# CTL-Workshop-Registration
This program is designed to act as registration software for the
Center for Teaching and Learning. This program uses the Spring Boot
framework to simply give access points to display the data the
CTL wants. The program simply uses HTML and the Java backend,
which takes advantage of Spring's annotations to access our mySQL
database.

The username and password is hardcoded in WebSecurityConfig.java and
the email address and password for the sender's email is hardcoded
MasterController.java

MySQL was used as our database. A dump file will be included in the file as well as a Database schema.
